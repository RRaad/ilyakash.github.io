$(document).ready(function() {
	$('.slider').slick({
		dots: true,
		infinite: true,
		cssEase: 'linear',
		arrows: false,
		autoplay: true,
		autoplaySpeed: 3000,
		mobileFirst: true
	});
});



